Name: Tri Doan
Course: 35B
Assignment: Lab 1
Due Date: 04/23/2019
Turn in Date: 04/23/2019

Description: In this project we will build a Car Configuration Application. 
In this unit  we will develop a �reference� base object model, 
read a text file to build the reference base object model and archive it using Serialization.

Sample Test Run
//					TEST RUN #1
/*
Focus Wagon ZTW   $18455.0
-------------------OPTION SET---------------------------------
Color
Transmission
Brakes/TractionControl
Side Impact Air Bags
Power Moonroof
-----------------OPTION--------------------------------
Fort Knox Gold Clearcoat Metallic
$0.0
Liquid Grey Clearcoat Metallic
$0.0
Infra-Red Clearcoat
$0.0
Grabber Green ClearcoatMetallic
$0.0
Sangria Red Clearcoat Metallic
$0.0
French Blue Clearcoat Metallic
$0.0
Twilight Blue Clearcoat Metallic
$0.0
CD Silver ClearcoatMetallic
$0.0
Pitch Black Clearcoat
$0.0
Cloud 9 White Clearcoat
$0.0

automatic
$0.0
manual
$-815.0

Standard
$0.0
ABS
$400.0
ABS with Advance Trac
$1625.0

present
$350.0
not present
$0.0

present
$595.0
not present
$0.0

2
-1
---------------------------------------------
Object has been deserialized 
Focus Wagon ZTW   $18455.0
-------------------OPTION SET---------------------------------
BodyKit
Brakes/TractionControl
Side Impact Air Bags
Power Moonroof
-----------------OPTION--------------------------------
manual
$-815.0

Standard
$0.0
ABS
$400.0
ABS with Advance Trac
$214.0

present
$350.0
Air Extension
$0.0

present
$595.0
not present
$0.0
 */